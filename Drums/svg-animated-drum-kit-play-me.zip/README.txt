A Pen created at CodePen.io. You can find this one at https://codepen.io/krevetkus/pen/zmyGqB.

 Rock out with this interactive svg animation, click, tap, or keys to play! Part of my [Pen's of Rock!](http://codepen.io/collection/APoYVq/) collection. Drawn in adobe illustrator, animated with greensock. Turn your speakers up for html audio elements in your ears!
Weird bounding box appears when tapped on mobile, any ideas?