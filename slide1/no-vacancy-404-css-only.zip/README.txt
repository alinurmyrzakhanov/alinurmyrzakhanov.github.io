A Pen created at CodePen.io. You can find this one at https://codepen.io/chriscoyier/pen/FmnGj.

 CSS version of No Vacancy 404 http://codepen.io/rileyjshaw/pen/ufEIH by Riley Shaw