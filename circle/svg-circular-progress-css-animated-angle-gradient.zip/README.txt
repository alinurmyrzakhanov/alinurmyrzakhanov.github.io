A Pen created at CodePen.io. You can find this one at https://codepen.io/saadeghi/pen/IBhfJ.

 SVG Circular Progress
CSS Animated
Angle Gradient

By Pouya Saadeghi