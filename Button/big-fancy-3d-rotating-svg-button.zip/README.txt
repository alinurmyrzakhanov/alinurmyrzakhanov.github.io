A Pen created at CodePen.io. You can find this one at https://codepen.io/jscottsmith/pen/ONjPzM.

 Button rotates in 3D when hovered and uses SVGs for dynamic text masking.  💅